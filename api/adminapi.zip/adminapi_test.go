package adminapi_test

import (
	"testing"

	"github.com/jare-abc/XrayR-dev/api"
	"github.com/jare-abc/XrayR-dev/api/adminapi"
)
